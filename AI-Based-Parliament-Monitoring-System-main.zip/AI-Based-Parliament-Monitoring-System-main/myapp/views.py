import json
import os
from dotenv import load_dotenv
load_dotenv()
from groq import Groq
import json
from django.contrib import messages
from django.db import models
from django.forms.models import model_to_dict
from django.http import Http404, JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_http_methods
from django.shortcuts import redirect
import requests
from .models import ( YouTubeVideo, USPVideo)
from django.core.files.base import ContentFile
from django.db import transaction
from .models import Citizen, MP
from django.shortcuts import render, redirect






from .models import (

    Citizen,

    MP,
    MPAdminID,
    MPFaceDetection,
    OfflineVideoUpload,
    USPComment,
    USPComplaint,
    USPFeedback,
    USPVote,
    USPVideo,
    YouTubeVideo,
)


def home(request):
    return render(request, 'home.html')


#------------------------login view-----------------------


def login_view(request):
    if request.method != "POST":
        return render(request, "login.html")

    role = (request.POST.get("role") or "").strip()

    # Citizen Login
    if role == "citizen":
        username = (request.POST.get("username") or "").strip()
        password = request.POST.get("password") or ""
        citizen_id = (request.POST.get("citizen_id") or "").strip()

        citizen = Citizen.objects.filter(
            username=username,
            password=password,
            citizen_id=citizen_id,
        ).first()

        if citizen:
            request.session["citizen_id"] = citizen.id
            # prevent session fixation
            request.session.modified = True
            return redirect("citizen_dashboard")

        messages.error(request, "Invalid Citizen Credentials")
        return render(request, "login.html")

    # MP Login
    if role == "mp":
        username = (request.POST.get("username") or "").strip()
        password = request.POST.get("password") or ""
        mp_id = (request.POST.get("mp_id") or "").strip()

        mp = MP.objects.filter(
            username=username,
            password=password,
            mp_id=mp_id,
        ).first()

        if mp:
            request.session["mp_id"] = mp.id
            request.session.modified = True
            return redirect("mp_dashboard")

        messages.error(request, "Invalid MP Credentials")
        return render(request, "login.html")

    # Admin Login
    if role == "admin":
        # Debug prints (required)
        print(request.POST)
        username = (request.POST.get("username") or "").strip()
        password = request.POST.get("password") or ""
        print(username)
        print(password)

        # Validate against MPAdminID model (username + password only)
        admin = MPAdminID.objects.filter(
            username=username,
            password=password,
            is_active=True,
        ).first()

        if admin:
            request.session["admin_id"] = admin.id
            request.session.modified = True
            return redirect('admin_dashboard')


        messages.error(request, "Invalid Admin Credentials")
        return render(request, "login.html")


    # Unknown / missing role
    messages.error(request, "Invalid Login Request")
    return render(request, "login.html")



#------------------------register view-----------------------

def register_view(request):

    if request.method == "POST":

        registration_type = request.POST.get(
            "registration_type"
        )

        # ==========================
        # Citizen Registration
        # ==========================
        if registration_type == "citizen":

            citizen = Citizen.objects.create(

                username=request.POST.get(
                    "citizen_username"
                ),

                password=request.POST.get(
                    "citizen_password"
                ),

                aadhar=request.POST.get(
                    "citizen_aadhar"
                ),

                pan=request.POST.get(
                    "citizen_pan"
                ),

                voter=request.POST.get(
                    "citizen_voter"
                ),

                name=request.POST.get(
                    "citizen_name"
                ),

                dob=request.POST.get(
                    "citizen_dob"
                ),

                age=request.POST.get(
                    "citizen_age"
                ),

                gender=request.POST.get(
                    "citizen_gender"
                ),

                category=request.POST.get(
                    "citizen_category"
                ),

                cast=request.POST.get(
                    "citizen_cast"
                ),

                email=request.POST.get(
                    "citizen_email"
                ),

                city=request.POST.get(
                    "citizen_city"
                ),

                state=request.POST.get(
                    "citizen_state"
                ),

                block=request.POST.get(
                    "citizen_block"
                ),

                address=request.POST.get(
                    "citizen_address"
                ),

                pincode=request.POST.get(
                    "citizen_pincode"
                ),

                aadhar_file=request.FILES.get(
                    "citizen_aadhar_file"
                ),

                pan_file=request.FILES.get(
                    "citizen_pan_file"
                ),

                voter_file=request.FILES.get(
                    "citizen_voter_file"
                ),

                profile_img=request.FILES.get(
                    "citizen_profile_img"
                )

            )

            return render(
                request,
                "registration_success.html",
                {
                    "user_type": "Citizen",
                    "user_id": citizen.citizen_id,
                    "username": citizen.username
                }
            )

        # ==========================
        # MP Registration
        # ==========================
        elif registration_type == "mp":

            mp = MP.objects.create(

                username=request.POST.get(
                    "mp_username"
                ),

                password=request.POST.get(
                    "mp_password"
                ),

                aadhar=request.POST.get(
                    "mp_aadhar"
                ),

                pan=request.POST.get(
                    "mp_pan"
                ),

                voter=request.POST.get(
                    "mp_voter"
                ),

                name=request.POST.get(
                    "mp_name"
                ),

                dob=request.POST.get(
                    "mp_dob"
                ),

                age=request.POST.get(
                    "mp_age"
                ),

                gender=request.POST.get(
                    "mp_gender"
                ),

                category=request.POST.get(
                    "mp_category"
                ),

                cast=request.POST.get(
                    "mp_cast"
                ),

                email=request.POST.get(
                    "mp_email"
                ),

                city=request.POST.get(
                    "mp_city"
                ),

                state=request.POST.get(
                    "mp_state"
                ),

                block=request.POST.get(
                    "mp_block"
                ),

                address=request.POST.get(
                    "mp_address"
                ),

                pincode=request.POST.get(
                    "mp_pincode"
                ),

                aadhar_file=request.FILES.get(
                    "mp_aadhar_file"
                ),

                pan_file=request.FILES.get(
                    "mp_pan_file"
                ),

                voter_file=request.FILES.get(
                    "mp_voter_file"
                ),

                profile_img=request.FILES.get(
                    "mp_profile_img"
                ),

                post_document=request.FILES.get(
                    "mp_post_document"
                ),

                post_id=request.POST.get(
                    "mp_post_id"
                )

            )

            return render(
                request,
                "registration_success.html",
                {
                    "user_type": "MP",
                    "user_id": mp.mp_id,
                    "username": mp.username
                }
            )

    return render(
        request,
        "register.html"
    )



# =====================================================
# ADMIN DASHBOARD (DYNAMIC MODEL LOADER)
# =====================================================

ADMIN_MODEL_REGISTRY = {
    "citizen": Citizen,
    "mp": MP,
    "mp_admin_id": MPAdminID,
    "mp_face_detection": MPFaceDetection,
    "offline_video_upload": OfflineVideoUpload,
    "youtube_video": YouTubeVideo,
    "usp_video": USPVideo,
    "usp_comment": USPComment,
    "usp_vote": USPVote,
    "usp_complaint": USPComplaint,
    "usp_feedback": USPFeedback,
}


def _citizen_authorized(request):
    return bool(request.session.get("citizen_id"))


def _mp_authorized(request):
    return bool(request.session.get("mp_id"))


def _admin_authorized(request):
    return bool(request.session.get("admin_id"))



def citizen_dashboard(request):

    if not _citizen_authorized(request):

        messages.error(
            request,
            "Please login as citizen to access dashboard"
        )

        return redirect(
            "login"
        )

    citizen = Citizen.objects.get(
        id=request.session["citizen_id"]
    )

    usp_videos = USPVideo.objects.all().order_by(
        "-id"
    )[:5]

    return render(
        request,
        "citizen_dashboard.html",
        {
            "citizen": citizen,
            "usp_videos": usp_videos
        }
    )



def mp_dashboard(request):
    if not _mp_authorized(request):
        messages.error(request, "Please login as MP to access dashboard")
        return redirect("login")
    return render(request, "mp_dashbord.html")



def citizen_data_page(request):
    """Admin page that renders the citizen_data.html template."""
    if not _admin_authorized(request):
        messages.error(request, "Please login as admin to access citizen data")
        return redirect("login")
    citizens = Citizen.objects.all().order_by("-id")
    return render(request, "citizen_data.html", {"citizens": citizens})



def admin_mp_data_page(request):
    if not _admin_authorized(request):
        messages.error(request, "Please login as admin to access MP data")
        return redirect("login")
    mps = MP.objects.all().order_by("-id")
    return render(request, "mp_data.html", {"mps": mps})



def admin_mp_admin_ids_page(request):
    if not _admin_authorized(request):
        messages.error(request, "Please login as admin to access MP Admin IDs")
        return redirect("login")
    admin_ids = MPAdminID.objects.select_related("mp").all().order_by("-created_at")
    return render(request, "mp_admin_ids.html", {"admin_ids": admin_ids})



def admin_mp_face_detections_page(request):
    if not _admin_authorized(request):
        messages.error(request, "Please login as admin to access MP Face Detection")
        return redirect("login")
    faces = MPFaceDetection.objects.all().order_by("-created_at")
    return render(request, "Mp face detections.html", {"faces": faces})


@require_http_methods(["GET"])
def mp_face_detection_list(request):
    if not _admin_authorized(request):
        return JsonResponse({"error": "unauthorized"}, status=403)

    faces_qs = MPFaceDetection.objects.all().order_by("-created_at")
    rows = []
    for face in faces_qs:
        rows.append(
            {
                "id": face.id,
                "name": face.name,
                "profile_image": face.profile_image.url if getattr(face, "profile_image", None) else "",
                "created_at": face.created_at.strftime("%Y-%m-%d %H:%M:%S"),
            }
        )

    return JsonResponse({"ok": True, "rows": rows})


@require_http_methods(["POST"])
def mp_face_single_upload(request):

    if not _admin_authorized(request):
        return JsonResponse({"error": "unauthorized"}, status=403)

    name = (request.POST.get("name") or "").strip()
    profile_image = request.FILES.get("profile_image")



    if not name:
        return JsonResponse({"ok": False, "error": "MP Name is required"}, status=400)
    if not profile_image:
        return JsonResponse({"ok": False, "error": "Profile Image is required"}, status=400)

    # Prevent duplicates by name (case-insensitive)
    if MPFaceDetection.objects.filter(name__iexact=name).exists():
        return JsonResponse({"ok": False, "error": "Duplicate MP name"}, status=400)

    with transaction.atomic():
        obj = MPFaceDetection(name=name)
        obj.profile_image.save(profile_image.name, profile_image, save=True)

    return JsonResponse({"ok": True, "id": obj.id})


@require_http_methods(["POST"])
def mp_face_excel_upload(request):

    if not _admin_authorized(request):
        return JsonResponse({"error": "unauthorized"}, status=403)

    excel_file = request.FILES.get("excel_file")
    if not excel_file:
        return JsonResponse({"ok": False, "error": "excel_file is required"}, status=400)

    # Per requirement:
    # Column A = MP Name
    # Column B = Embedded image (Excel picture)
    # Support only embedded images inside .xlsx.
    filename = (excel_file.name or "").lower()
    if not filename.endswith('.xlsx'):
        return JsonResponse({"ok": False, "error": "Only .xlsx files with embedded images (Column A: name, Column B: image) are supported"}, status=400)

    from openpyxl import load_workbook

    try:
        excel_file.seek(0)
        wb = load_workbook(excel_file, read_only=False, data_only=True)
        ws = wb.worksheets[0]
    except Exception as e:
        return JsonResponse({"ok": False, "error": f"Unable to read .xlsx: {e}"}, status=400)

    # Map image anchor row -> image bytes
    # openpyxl stores images in ws._images; each has .anchor with a cell reference.
    image_by_row = {}
    try:
        for img in getattr(ws, "_images", []):
            try:
                # For one-cell anchors
                anchor = getattr(img, "anchor", None)
                if anchor is None:
                    continue

                # Different openpyxl versions store anchor differently
                # Common: anchor._from.row is 0-based
                row_0_based = None
                col_0_based = None
                if hasattr(anchor, "_from"):
                    row_0_based = getattr(anchor._from, "row", None)
                    col_0_based = getattr(anchor._from, "col", None)
                elif hasattr(anchor, "row"):
                    row_0_based = getattr(anchor, "row", None)
                    col_0_based = getattr(anchor, "col", None)

                if row_0_based is None:
                    continue

                # openpyxl uses 0-based row/col in anchor._from
                excel_row = int(row_0_based) + 1
                # We only care about images anchored in Column B (index 1 -> col 2 in Excel)
                if col_0_based is not None and int(col_0_based) != 1:
                    # anchor not in column B
                    continue

                # extract image bytes
                img_bytes = img._data() if hasattr(img, "_data") else None
                if not img_bytes:
                    continue

                image_by_row[excel_row] = img_bytes
            except Exception:
                continue
    except Exception:
        pass

    created = 0
    failed = 0
    errors = []
    total_rows = 0

    # Iterate Excel rows: Column A (name) and Column B (embedded image)
    # Skip header row if it exists: we’ll ignore rows where name looks like "name".
    max_row = ws.max_row or 0
    total_rows = max_row

    from io import BytesIO

    def _guess_ext_from_bytes(b: bytes):
        # Minimal magic-number detection
        if b.startswith(b"\x89PNG"):
            return "png"
        return "jpg"

    for r in range(1, max_row + 1):
        try:
            name_cell = ws.cell(row=r, column=1)  # Column A
            name_val = name_cell.value
            name = (str(name_val).strip() if name_val is not None else "")

            # skip header-like row
            if not name or name.lower().replace(" ", "") in ("name", "mpname", "mp_name"):
                continue

            # Column B: can be an embedded Excel picture OR an image filename like "vinod.jpg"
            img_cell = ws.cell(row=r, column=2)  # Column B
            img_cell_val = img_cell.value
            img_ref = (str(img_cell_val).strip() if img_cell_val is not None else "")

            if not img_ref:
                failed += 1
                errors.append(f"Row {r}: Image reference is required in Column B")
                continue

            if MPFaceDetection.objects.filter(name__iexact=name).exists():
                failed += 1
                errors.append(f"Row {r}: Duplicate name '{name}'")
                continue

            # Case 1: embedded image already extracted by openpyxl (key = Excel row)
            if r in image_by_row:
                img_bytes = image_by_row[r]
                ext = _guess_ext_from_bytes(img_bytes)
                obj = MPFaceDetection(name=name)
                obj.profile_image.save(
                    f"mp_face_{r}.{ext}",
                    ContentFile(img_bytes),
                    save=True,
                )
                created += 1
                continue

            # Case 2: Column B holds a filename. Must locate BASE_DIR/mp_images/<filename>
            import os
            from django.conf import settings

            safe_filename = os.path.basename(img_ref)  # prevent path traversal
            mp_images_dir = os.path.join(str(settings.BASE_DIR), "mp_images")
            source_path = os.path.join(mp_images_dir, safe_filename)

            if not os.path.exists(source_path):
                failed += 1
                errors.append(
                    f"Row {r}: Missing source image file for '{name}': {source_path}"
                )
                continue

            with open(source_path, "rb") as f:
                file_bytes = f.read()

            _, ext = os.path.splitext(safe_filename)
            ext = ext.lstrip(".").lower() or "jpg"

            obj = MPFaceDetection(name=name)
            # Do NOT save filename only; save actual bytes into ImageField
            obj.profile_image.save(
                safe_filename,
                ContentFile(file_bytes),
                save=True,
            )
            created += 1

        except Exception as e:
            failed += 1
            errors.append(f"Row {r}: {e}")


    return JsonResponse({"ok": True, "total": total_rows, "created": created, "failed": failed, "errors": errors})




def mp_face_single_edit(request):
    if not _admin_authorized(request):
        return JsonResponse({"error": "unauthorized"}, status=403)

    face_id = request.POST.get("id")
    name = (request.POST.get("name") or "").strip()
    profile_image = request.FILES.get("profile_image")

    if not face_id:
        return JsonResponse({"ok": False, "error": "id is required"}, status=400)
    if not name:
        return JsonResponse({"ok": False, "error": "MP Name is required"}, status=400)

    face = get_object_or_404(MPFaceDetection, pk=face_id)

    # Prevent duplicates by name (case-insensitive), excluding current record
    if MPFaceDetection.objects.filter(name__iexact=name).exclude(pk=face.pk).exists():
        return JsonResponse({"ok": False, "error": "Duplicate MP name"}, status=400)

    with transaction.atomic():
        face.name = name
        if profile_image:
            face.profile_image.save(profile_image.name, profile_image, save=True)
        else:
            face.save()

    return JsonResponse({"ok": True, "id": face.id})


@require_http_methods(["POST"])
def mp_face_delete(request):
    if not _admin_authorized(request):
        return JsonResponse({"error": "unauthorized"}, status=403)

    face_id = request.POST.get("id")
    if not face_id:
        return JsonResponse({"ok": False, "error": "id is required"}, status=400)

    face = get_object_or_404(MPFaceDetection, pk=face_id)
    with transaction.atomic():
        face.delete()

    return JsonResponse({"ok": True})


def iter_zip_images(zip_file):
    """Yield (path_in_zip, bytes) for image files inside a zip."""
    import zipfile as _zipfile

    # Some callers may pass an already-open ZipFile; support both.
    zf = zip_file if hasattr(zip_file, "infolist") else _zipfile.ZipFile(zip_file)

    for info in zf.infolist():
        if info.is_dir():
            continue
        name = info.filename
        lower = name.lower()
        if not (lower.endswith(".jpg") or lower.endswith(".jpeg") or lower.endswith(".png") or lower.endswith(".webp")):
            continue
        data = zf.read(info)
        yield name, data


@require_http_methods(["POST"])
def mp_face_zip_upload(request):


    if not _admin_authorized(request):
        return JsonResponse({"error": "unauthorized"}, status=403)

    zip_file = request.FILES.get("zip_file")
    if not zip_file:
        return JsonResponse({"ok": False, "error": "zip_file is required"}, status=400)



    created = 0
    failed = 0
    errors = []

    try:
        import zipfile
        zf = zipfile.ZipFile(zip_file)

        # Collect first image per folder (MP Name)
        # Folder structure: MP Name/filename.jpg
        folder_to_first_img = {}
        for path_in_zip, data in iter_zip_images(zf):
            parts = path_in_zip.split('/')
            if len(parts) < 2:
                continue
            folder = '/'.join(parts[:-1])
            mp_name = folder.split('/')[-1]
            mp_name = mp_name.strip()
            if not mp_name:
                continue
            if mp_name not in folder_to_first_img:
                folder_to_first_img[mp_name] = (parts[-1], data)

        with transaction.atomic():
            for mp_name, (img_filename, img_bytes) in folder_to_first_img.items():
                if MPFaceDetection.objects.filter(name__iexact=mp_name).exists():
                    failed += 1
                    errors.append(f"Duplicate name '{mp_name}'")
                    continue
                try:
                    obj = MPFaceDetection(name=mp_name)
                    # infer ext
                    lower = img_filename.lower()
                    ext = 'jpg'
                    if lower.endswith('.png'):
                        ext = 'png'
                    obj.profile_image.save(img_filename, ContentFile(img_bytes), save=True)
                    created += 1
                except Exception as e:
                    failed += 1
                    errors.append(f"{mp_name}: {e}")

    except Exception as e:
        return JsonResponse({"ok": False, "error": str(e)}, status=500)

    return JsonResponse({"ok": True, "created": created, "failed": failed, "errors": errors})



@require_http_methods(["POST"])
def api_mp_face_detections_create_bulk(request):


    """Create MPFaceDetection rows from bulk payload.

    Expects JSON body: {"rows": [{"name": "...", "profile_image": "..."}, ...]}

    NOTE:
    - In your UI you send `profile_image`.
    - You want Excel columns: name + image (you said: "name , imge").
      Frontend currently maps second column into `profile_image`.
    """
    if not _admin_authorized(request):
        return JsonResponse({"error": "unauthorized"}, status=403)

    try:
        payload = json.loads(request.body.decode("utf-8") or "{}")
    except json.JSONDecodeError:
        payload = {}

    rows = payload.get("rows") or []
    if not isinstance(rows, list):
        return JsonResponse({"error": "rows must be a list"}, status=400)

    created = 0
    failed = 0
    errors = []

    for i, row in enumerate(rows):
        if not isinstance(row, dict):
            failed += 1
            errors.append(f"Row {i+1}: Invalid row payload")
            continue

        name = row.get("name")
        # Support multiple possible key spellings
        profile_image = row.get("profile_image") or row.get("images") or row.get("imge") or row.get("image")

        name = str(name).strip() if name is not None else ""
        profile_image = str(profile_image).strip() if profile_image is not None else ""

        if not name:
            failed += 1
            errors.append(f"Row {i+1}: Missing name")
            continue
        if not profile_image:
            failed += 1
            errors.append(f"Row {i+1}: Missing image")
            continue

        # Prevent duplicates by name (case-insensitive)
        if MPFaceDetection.objects.filter(name__iexact=name).exists():
            failed += 1
            errors.append(f"Row {i+1}: Duplicate name '{name}'")
            continue

        # IMPORTANT:
        # MPFaceDetection.profile_image is an ImageField (needs an uploaded file).
        # For now, we only accept URLs and download them server-side.
        # If you provide only local filenames, backend cannot access your Excel PC path.
        try:
            import os
            import uuid
            import tempfile
            import requests

            # If it's a URL -> download. If it's a filename -> reject with clear message.
            if not (profile_image.startswith("http://") or profile_image.startswith("https://")):
                failed += 1
                errors.append(
                    f"Row {i+1}: profile_image must be a full URL (https://...). Got filename: '{profile_image}'"
                )
                continue

            resp = requests.get(profile_image, timeout=30)
            if resp.status_code != 200:
                failed += 1
                errors.append(f"Row {i+1}: Cannot download image for '{name}'. HTTP {resp.status_code}")
                continue

            content_type = resp.headers.get("content-type", "")
            ext = "jpg"
            if "png" in content_type:
                ext = "png"
            elif "jpeg" in content_type:
                ext = "jpg"

            tmp_dir = tempfile.gettempdir()
            filename = f"mp_face_{uuid.uuid4().hex[:10]}.{ext}"
            tmp_path = os.path.join(tmp_dir, filename)
            with open(tmp_path, "wb") as f:
                f.write(resp.content)

            with open(tmp_path, "rb") as f:
                obj = MPFaceDetection(name=name)
                # This saves file into MEDIA/mp_face_detection/
                obj.profile_image.save(filename, f, save=True)

            # cleanup tmp file
            try:
                os.remove(tmp_path)
            except Exception:
                pass

            created += 1
        except Exception as e:
            failed += 1
            errors.append(f"Row {i+1}: Error saving '{name}': {e}")
            continue

    return JsonResponse({"ok": True, "created": created, "failed": failed, "errors": errors})





def admin_offline_video_uploads_page(request):
    if not _admin_authorized(request):
        messages.error(request, "Please login as admin to access Offline Video Uploads")
        return redirect("login")

    # Must be JSON serializable because template uses {{ videos|json_script:"offline-videos" }}
    # json_script does not accept a raw QuerySet in Django.
    videos_qs = OfflineVideoUpload.objects.all().order_by("-uploaded_at")
    videos = [
        {
            "id": v.id,
            "video_id": getattr(v, "video_id", ""),
            "title": getattr(v, "title", ""),
            "channel_name": getattr(v, "channel_name", ""),
            "video_file": v.video_file.url if getattr(v, "video_file", None) else "",
            "uploaded_at": v.uploaded_at.strftime("%Y-%m-%d %H:%M:%S") if getattr(v, "uploaded_at", None) else "",
            "description_ui": getattr(v, "description", "") if hasattr(v, "description") else "",
            "tags_ui": getattr(v, "tags", "") if hasattr(v, "tags") else "",
        }
        for v in videos_qs
    ]

    return render(request, "offline_video_uplode.html", {"videos": videos})




def admin_youtube_videos_page(request):
    if not _admin_authorized(request):
        messages.error(request, "Please login as admin to access YouTube Videos")
        return redirect("login")
    youtube_videos = YouTubeVideo.objects.all().order_by("-created_at")
    return render(request, "youtube videos.html", {"youtube_videos": youtube_videos})




def admin_usp_videos_page(request):
    if not _admin_authorized(request):
        messages.error(request, "Please login as admin to access USP Videos")
        return redirect("login")
    usp_videos = USPVideo.objects.all().order_by("-created_at")
    return render(request, "USP_videos.html", {"usp_videos": usp_videos})



def admin_comments_page(request):
    if not _admin_authorized(request):
        messages.error(request, "Please login as admin to access Comments")
        return redirect("login")
    comments = (
        USPComment.objects.select_related("usp_video", "citizen", "usp_video__youtube_video", "mp")
        .order_by("-created_at")
    )
    return render(request, "admin_comment.html", {"comments": comments})



def admin_votes_page(request):
    if not _admin_authorized(request):
        messages.error(request, "Please login as admin to access Votes")
        return redirect("login")
    votes = (
        USPVote.objects.select_related("usp_video", "citizen", "usp_video__youtube_video", "mp")
        .order_by("-created_at")
    )
    return render(request, "admin_vote.html", {"votes": votes})



def admin_complaints_page(request):
    if not _admin_authorized(request):
        messages.error(request, "Please login as admin to access Complaints")
        return redirect("login")
    complaints = (
        USPComplaint.objects.select_related("usp_video", "citizen", "usp_video__youtube_video", "mp")
        .order_by("-created_at")
    )
    return render(request, "admin_complent.html", {"complaints": complaints})




def admin_feedback_page(request):
    if not _admin_authorized(request):
        messages.error(request, "Please login as admin to access Feedback")
        return redirect("login")
    feedbacks = (
        USPFeedback.objects.select_related("usp_video", "citizen", "usp_video__youtube_video", "mp")
        .order_by("-created_at")
    )
    return render(request, "admin_feedback.html", {"feedbacks": feedbacks})







def logout_view(request):
    # Clear all role sessions
    request.session.flush()
    messages.success(request, "Logged out successfully")
    return redirect("login")


def admin_dashboard(request):

    if not _admin_authorized(request):
        messages.error(request, "Please login as admin to access dashboard")
        return redirect("login")


    # Totals + sidebar counts
    totals = {
        # Requirement: Do NOT load citizen records inside the dashboard right panel.
        "citizen": 0,
        "mp": MP.objects.count(),
        "mp_admin_id": MPAdminID.objects.count(),
        "mp_face_detection": MPFaceDetection.objects.count(),
        "offline_video_upload": OfflineVideoUpload.objects.count(),
        "youtube_video": YouTubeVideo.objects.count(),
        "usp_video": USPVideo.objects.count(),
        "usp_comment": USPComment.objects.count(),
        "usp_vote": USPVote.objects.count(),
        "usp_complaint": USPComplaint.objects.count(),
        "usp_feedback": USPFeedback.objects.count(),
    }


    # USP Analytics based on USPVideo fields
    usp_analytics = {
        "usp_total_views": USPVideo.objects.aggregate(models.Sum("total_views"))[
            "total_views__sum"
        ]
        or 0,
        "usp_total_likes": USPVideo.objects.aggregate(models.Sum("total_likes"))[
            "total_likes__sum"
        ]
        or 0,
        "usp_total_dislikes": USPVideo.objects.aggregate(models.Sum("total_dislikes"))[
            "total_dislikes__sum"
        ]
        or 0,
        "usp_total_comments": USPVideo.objects.aggregate(models.Sum("total_comments"))[
            "total_comments__sum"
        ]
        or 0,
        "usp_total_complaints": USPVideo.objects.aggregate(models.Sum("total_complaints"))[
            "total_complaints__sum"
        ]
        or 0,
        "usp_total_feedbacks": USPVideo.objects.aggregate(models.Sum("total_feedbacks"))[
            "total_feedbacks__sum"
        ]
        or 0,
    }

    # Admin profile (real logged-in admin)
    admin_profile = None
    admin_obj = None
    admin_id = request.session.get("admin_id")
    if admin_id:
        admin_obj = MPAdminID.objects.select_related("mp").filter(pk=admin_id).first()

    if admin_obj:
        admin_profile = {
            "admin_name": getattr(admin_obj.mp, "name", "") if hasattr(admin_obj, "mp") else "",
            "admin_username": getattr(admin_obj, "username", ""),
            "admin_admin_id": getattr(admin_obj, "admin_id", ""),
            # MPAdminID has no email field; use MP email if available
            "admin_email": getattr(getattr(admin_obj, "mp", None), "email", "") or "",
            "admin_profile_img_url": None,
        }

    # Recent records for overview (latest only)
    recent = {
        # Requirement: Do NOT load citizen records inside the dashboard right panel.
        "latest_citizens": [],
        "latest_mps": MP.objects.order_by("-id").all()[:5],
        "latest_youtube_videos": YouTubeVideo.objects.order_by("-id").all()[:5],
        "latest_usp_videos": USPVideo.objects.order_by("-id").all()[:5],
        "latest_comments": USPComment.objects.order_by("-created_at").all()[:5],
        "latest_complaints": USPComplaint.objects.order_by("-created_at").all()[:5],
        "latest_feedback": USPFeedback.objects.order_by("-created_at").all()[:5],
    }


    return render(
        request,
        "admin_dashboard.html",
        {
            "admin_model_registry": ADMIN_MODEL_REGISTRY,
            "admin_profile": admin_profile or {},
            "totals": totals,
            "usp_analytics": usp_analytics,
            "recent": recent,
        },
    )


def _serialize_record(instance, model_cls):
    data = {"id": getattr(instance, "pk", None)}
    for f in model_cls._meta.get_fields():

        if f.auto_created and not f.concrete:
            continue

        # Skip reverse relations
        if not getattr(f, "concrete", True) and getattr(f, "many_to_one", False) is False:
            continue

        if isinstance(f, models.ForeignKey):
            val = getattr(instance, f.attname, None)
            data[f.name] = val
        else:
            try:
                val = getattr(instance, f.name)
            except Exception:
                continue
            # JSON serialize for common types
            if isinstance(val, (models.Model,)):
                data[f.name] = str(val)
            # If it's a QuerySet (e.g., accidental assignment / reverse relation), convert safely
            elif hasattr(val, "all") and val.__class__.__name__ == "QuerySet":
                data[f.name] = [str(x) for x in val]
            else:
                # Ensure JSON-serializable primitives
                if hasattr(val, "isoformat"):
                    data[f.name] = val.isoformat()
                else:
                    data[f.name] = val
    return data


def _model_fields_metadata(model_cls):
    cols = []
    for f in model_cls._meta.get_fields():
        if f.auto_created and not f.concrete:
            continue
        if not getattr(f, "concrete", True) and not isinstance(f, models.ForeignKey):
            # Skip reverse relations
            continue

        col = {
            "key": f.name,
            "label": getattr(f, "verbose_name", f.name) or f.name,
        }
        cols.append(col)
    return cols


@require_http_methods(["GET"])
def admin_model_data(request, model_key):
    if not _admin_authorized(request):
        return JsonResponse({"error": "unauthorized"}, status=403)

    model_cls = ADMIN_MODEL_REGISTRY.get(model_key)
    if not model_cls:
        raise Http404("Unknown model")

    q = (request.GET.get("search") or "").strip()
    sort_by = request.GET.get("sort_by") or "id"
    sort_dir = request.GET.get("sort_dir") or "desc"

    try:
        page = int(request.GET.get("page") or 1)
        page_size = int(request.GET.get("page_size") or 10)
    except ValueError:
        page = 1
        page_size = 10

    page = max(page, 1)
    page_size = min(max(page_size, 1), 100)

    qs = model_cls.objects.all()

    # Basic search across text fields
    if q:
        search_q = models.Q()
        for f in model_cls._meta.get_fields():
            if getattr(f, "concrete", False) and isinstance(f, (models.CharField, models.TextField)):
                search_q |= models.Q(**{f"{f.name}__icontains": q})
        if search_q:
            qs = qs.filter(search_q)

    # Basic filter support: status/is_active
    status = request.GET.get("status")
    if status is not None and "status" in [f.name for f in model_cls._meta.get_fields() if getattr(f, "concrete", False)]:
        qs = qs.filter(status=status)

    is_active = request.GET.get("is_active")
    if is_active is not None and "is_active" in [f.name for f in model_cls._meta.get_fields() if getattr(f, "concrete", False)]:
        if is_active.lower() in ("true", "1", "yes"):
            qs = qs.filter(is_active=True)
        elif is_active.lower() in ("false", "0", "no"):
            qs = qs.filter(is_active=False)

    # Sort
    if sort_by:
        prefix = "-" if sort_dir.lower() == "desc" else ""
        if sort_by in [f.name for f in model_cls._meta.get_fields()]:
            qs = qs.order_by(f"{prefix}{sort_by}")

    total = qs.count()
    start = (page - 1) * page_size
    end = start + page_size

    rows = []
    for obj in qs[start:end]:
        rows.append(_serialize_record(obj, model_cls))

    return JsonResponse(
        {
            "model": model_key,
            "columns": _model_fields_metadata(model_cls),
            "rows": rows,
            "total": total,
            "page": page,
            "page_size": page_size,
        },
        safe=False,
    )


@require_http_methods(["POST"])
def admin_model_crud(request, model_key, pk, action):

    if not _admin_authorized(request):
        return JsonResponse({"error": "unauthorized"}, status=403)

    model_cls = ADMIN_MODEL_REGISTRY.get(model_key)
    if not model_cls:
        raise Http404("Unknown model")

    obj = get_object_or_404(model_cls, pk=pk)

    if action == "delete":
        obj.delete()
        return JsonResponse({"ok": True})

    if action == "view":
        return JsonResponse({"ok": True, "data": _serialize_record(obj, model_cls)})

    if action == "edit":
        payload = request.body.decode("utf-8")
        try:
            data = json.loads(payload) if payload else {}
        except json.JSONDecodeError:
            data = {}

        # Only update concrete fields
        for f in model_cls._meta.get_fields():
            if not getattr(f, "concrete", False):
                continue
            if f.name in data:
                setattr(obj, f.name, data[f.name])
        obj.save()
        return JsonResponse({"ok": True, "data": _serialize_record(obj, model_cls)})

    if action == "create":
        payload = request.body.decode("utf-8")
        try:
            data = json.loads(payload) if payload else {}
        except json.JSONDecodeError:
            data = {}

        new_obj = model_cls()

        # Only allow setting concrete fields (skip primary key and auto fields)
        for f in model_cls._meta.get_fields():
            if not getattr(f, "concrete", False):
                continue
            if f.primary_key:
                continue
            if getattr(f, "auto_created", False):
                continue
            if f.name in data:
                setattr(new_obj, f.name, data[f.name])

        new_obj.save()
        return JsonResponse({"ok": True, "data": _serialize_record(new_obj, model_cls)})


    if action in ("change_password", "password_change"):

        payload = request.body.decode("utf-8")
        try:
            data = json.loads(payload) if payload else {}
        except json.JSONDecodeError:
            data = {}

        new_password = data.get("new_password") or data.get("password")
        if not new_password:
            return JsonResponse({"error": "new_password required"}, status=400)

        if not hasattr(obj, "password"):
            return JsonResponse({"error": "password field not available"}, status=400)

        setattr(obj, "password", new_password)
        obj.save()
        return JsonResponse({"ok": True, "data": _serialize_record(obj, model_cls)})

    if action in ("activate", "deactivate", "toggle_active"):
        # Only MPAdminID supports this toggle
        if not hasattr(obj, "is_active"):
            return JsonResponse({"error": "is_active field not available"}, status=400)

        if action == "activate":
            obj.is_active = True
        elif action == "deactivate":
            obj.is_active = False
        else:
            obj.is_active = not bool(getattr(obj, "is_active", True))

        obj.save()
        return JsonResponse({"ok": True, "data": _serialize_record(obj, model_cls)})

    return JsonResponse({"error": "unknown action"}, status=400)


#----------------------#


from django.shortcuts import render
from django.conf import settings
from youtube_transcript_api import YouTubeTranscriptApi
from .models import YouTubeVideo
from youtube_transcript_api import YouTubeTranscriptApi
import yt_dlp
import os
from .models import YouTubeVideo

def youtube_upload(request):

    message = ""

    if request.method == "POST":

        try:

            print("=" * 50)
            print("POST REQUEST RECEIVED")

            youtube_url = request.POST.get("youtube_url", "").strip()
            video_id = request.POST.get("video_id", "").strip()
            channel_name = request.POST.get("channel_name", "").strip()

            print("URL :", youtube_url)
            print("VIDEO ID :", video_id)
            print("CHANNEL :", channel_name)

            # ==========================
            # Download Video
            # ==========================

            save_dir = os.path.join(
                settings.MEDIA_ROOT,
                "youtube_videos"
            )

            os.makedirs(save_dir, exist_ok=True)

            ydl_opts = {
                "format": "best",
                "outtmpl": os.path.join(
                    save_dir,
                    "%(title)s.%(ext)s"
                ),
                "extractor_args": {
                    "youtube": {
                        "player_client": ["android"]
                    }
                }
            }

            print("STARTING DOWNLOAD")

            with yt_dlp.YoutubeDL(ydl_opts) as ydl:

                info = ydl.extract_info(
                    youtube_url,
                    download=True
                )

                title = info.get("title", "")

                downloaded_file = ydl.prepare_filename(info)

            print("DOWNLOAD COMPLETE")

            # ==========================
            # Transcript
            # ==========================

            print("GETTING TRANSCRIPT")

            ytt_api = YouTubeTranscriptApi()

            try:

                fetched_transcript = ytt_api.fetch(
                    video_id,
                    languages=['hi', 'en']
                )

            except Exception as e:

                print("Transcript Error:", e)
                fetched_transcript = []

            transcript_data = []

            for item in fetched_transcript:

                transcript_data.append({
                    "start": item.start,
                    "duration": item.duration,
                    "text": item.text
                })

            print("TRANSCRIPT COMPLETE")

            # ==========================
            # Summary
            # ==========================

            summary_text = " ".join(
                [x["text"] for x in transcript_data]
            )

            relative_path = os.path.relpath(
                downloaded_file,
                settings.MEDIA_ROOT
            )

            # ==========================
            # Save Database
            # ==========================

            video = YouTubeVideo.objects.create(
                youtube_url=youtube_url,
                video_id=video_id,
                title=title,
                channel_name=channel_name,
                transcript=transcript_data,
                summary_text=summary_text
            )

            video.video_file = relative_path
            video.save()

            print("DATABASE SAVED")

            message = "Video Saved Successfully"

        except Exception as e:

            print("ERROR FOUND")
            print(str(e))

            message = f"Error : {e}"

    videos = YouTubeVideo.objects.all().order_by('-id')

    print("TOTAL VIDEOS =", videos.count())

    return render(
        request,
        "youtube videos.html",
        {
            "message": message,
            "videos": videos
        }
    )
    
    
#-------------------------------------

from django.shortcuts import redirect
from .models import YouTubeVideo, USPVideo

def generate_usp_video(request, pk):

    youtube_video = YouTubeVideo.objects.get(id=pk)

    summary_text = youtube_video.summary_text

    print("SUMMARY LENGTH =", len(summary_text))

    CHUNK_SIZE = 12000

    summary_chunks = [
        summary_text[i:i + CHUNK_SIZE]
        for i in range(
            0,
            len(summary_text),
            CHUNK_SIZE
        )
    ]

    print("TOTAL CHUNKS =", len(summary_chunks))

    client = Groq(
        api_key=os.getenv("GROQ_API_KEY")
    )

    all_topics = []
    all_summaries = []

    for index, chunk in enumerate(summary_chunks):

        print(f"PROCESSING CHUNK {index + 1}")

        chunk_prompt = f"""
आप एक संसद विश्लेषक हैं।

कार्य:

1. चर्चा में जितने अलग-अलग मुद्दे हैं उन्हें पहचानो।
2. हर मुद्दे के नीचे महत्वपूर्ण Highlights दो।
3. अंत में एक लाइन सारांश दो।
4. Output केवल JSON में दो।

महत्वपूर्ण निर्देश:

1. व्यक्तियों पर नहीं, मुद्दों (Issues) पर फोकस करो।
2. सांसदों या नेताओं के नामों का उपयोग कम से कम करो।
3. Topic का नाम मुद्दा होना चाहिए, व्यक्ति का नाम नहीं।
4. Highlights नागरिकों को विषय समझाने वाले हों।
5. Output समाचार विश्लेषण जैसा हो।
6. यदि एक ही विषय पर कई नेताओं ने बात की हो तो उसे एक ही Topic में जोड़ो।
7. Topic का नाम "राहुल गांधी", "अनुराग ठाकुर" जैसे व्यक्ति के नाम पर नहीं होना चाहिए।
8. केवल संसद में उठे मुद्दों और उनके प्रभाव पर ध्यान दो।

JSON Format:

{{
    "topics":[
        {{
            "title":"मुद्दे का नाम",
            "highlights":[
                "Point 1",
                "Point 2",
                "Point 3"
            ]
        }}
    ],

    "one_line_summary":"One line summary"
}}

Summary:

{chunk}
"""

        response = client.chat.completions.create(
            model="llama-3.3-70b-versatile",
            messages=[
                {
                    "role": "user",
                    "content": chunk_prompt
                }
            ],
            temperature=0.3
        )

        groq_text = response.choices[0].message.content

        try:

            groq_text = groq_text.replace(
                "```json",
                ""
            )

            groq_text = groq_text.replace(
                "```",
                ""
            )

            data = json.loads(
                groq_text.strip()
            )

            all_topics.extend(
                data.get(
                    "topics",
                    []
                )
            )

            all_summaries.append(
                data.get(
                    "one_line_summary",
                    ""
                )
            )

        except Exception as e:

            print(
                "CHUNK ERROR =",
                e
            )

    merged_topics = {}

    for topic in all_topics:

        title = topic.get(
            "title",
            ""
        ).strip()

        if not title:
            continue

        if title not in merged_topics:

            merged_topics[title] = []

        merged_topics[title].extend(
            topic.get(
                "highlights",
                []
            )
        )

    highlights_data = {

        "topics": [

            {
                "title": title,

                "highlights": list(
                    set(highlights)
                )
            }

            for title, highlights
            in merged_topics.items()

        ],

        "one_line_summary": " ".join(
            all_summaries
        )
    }

    USPVideo.objects.create(

        youtube_video=youtube_video,

        title=youtube_video.title,

        original_video_id=youtube_video.video_id,

        video_file=youtube_video.video_file,

        transcript=youtube_video.transcript,

        summary=youtube_video.summary_text,

        highlights=highlights_data,

        mp_speeches=[]
    )

    return redirect('usp_videos')

#----------------------------------------------

from .models import USPVideo, USPComment

def live_session(request):

    live_video = USPVideo.objects.filter(
        is_live=True
    ).first()

    comments = []
    
    transcript = []

    if live_video:

        comments = USPComment.objects.filter(
            usp_video=live_video
        ).order_by('-created_at')
        transcript = live_video.transcript

    return render(
        request,
        "live_session.html",
        {
            "live_video": live_video,
            "comments": comments,
            "transcript": transcript
        }
    )
def session_player(request):

    videos = USPVideo.objects.all().order_by('-id')

    live_video = USPVideo.objects.filter(
        is_live=True
    ).first()

    return render(
        request,
        'session_player.html',
        {
            'videos': videos,
            'live_video': live_video
        }
    )





#------------------------------------------------------------
def go_live(request, pk):

    USPVideo.objects.update(
        is_live=False
    )

    video = USPVideo.objects.get(
        id=pk
    )

    video.is_live = True

    video.save()

    return redirect(
        'session_player'
    )


def stop_live(request):

    USPVideo.objects.update(
        is_live=False
    )

    return redirect(
        'session_player'
    )
    
    
    #-------------------------------comments --
def add_comment(request, pk):

    if request.method == "POST":

        usp_video = USPVideo.objects.get(
            id=pk
        )

        citizen_id = request.session.get(
            "citizen_id"
        )
        citizen = Citizen.objects.get(
            id=citizen_id
        )

        comment_text = request.POST.get(
            "comment"
        )

        USPComment.objects.create(

            usp_video=usp_video,

            citizen=citizen,

            comment=comment_text
        )

        usp_video.total_comments += 1

        usp_video.save()

    return redirect(
        'live_session'
    )
    
    #----------------------vote----------
def add_vote(request, pk):

    if request.method == "POST":

        usp_video = USPVideo.objects.get(
            id=pk
        )

        citizen_id = request.session.get(
            "citizen_id"
        )
        citizen = Citizen.objects.get(
            id=citizen_id
        )

        vote_type = request.POST.get(
            "vote_type"
        )

        old_vote = USPVote.objects.filter(
            usp_video=usp_video,
            citizen=citizen
        ).first()

        if old_vote:

            if old_vote.vote_type == vote_type:

                return redirect(
                    'live_session'
                )

            if old_vote.vote_type == "like":

                usp_video.total_likes -= 1

            else:

                usp_video.total_dislikes -= 1

            old_vote.vote_type = vote_type

            old_vote.save()

        else:

            USPVote.objects.create(

                usp_video=usp_video,

                citizen=citizen,

                vote_type=vote_type
            )

        if vote_type == "like":

            usp_video.total_likes += 1

        else:

            usp_video.total_dislikes += 1

        usp_video.save()

    return redirect(
        'live_session'
    )
    #------------------feedback--------------
def add_feedback(request, pk):

    if request.method == "POST":

        usp_video = USPVideo.objects.get(
            id=pk
        )

        citizen_id = request.session.get(
            "citizen_id"
        )
        citizen = Citizen.objects.get(
            id=citizen_id
        )
        
        feedback_text = request.POST.get(
            "feedback"
        )

        USPFeedback.objects.create(

            usp_video=usp_video,

            citizen=citizen,

            rating=5,

            message=feedback_text
        )

        usp_video.total_feedbacks += 1

        usp_video.save()

    return redirect(
        'live_session'
    )
    
    #----------------complaint--------------
def add_complaint(request, pk):

    if request.method == "POST":

        usp_video = USPVideo.objects.get(
            id=pk
        )

        citizen_id = request.session.get(
            "citizen_id"
        )
        citizen = Citizen.objects.get(
            id=citizen_id
        )

        complaint_text = request.POST.get(
            "complaint"
        )

        USPComplaint.objects.create(

            usp_video=usp_video,

            citizen=citizen,

            message=complaint_text
        )

        usp_video.total_complaints += 1

        usp_video.save()

    return redirect(
        'live_session'
    )       
    
    #------------session-history----------------
    
def session_history(request):

    videos = USPVideo.objects.all().order_by(
        '-created_at'
    )

    return render(
        request,
        'session_history.html',
        {
            'videos': videos
        }
    )
    #-------------------session_details----------
    
def session_details(request, pk):

    video = USPVideo.objects.get(
        id=pk
    )

    comments = USPComment.objects.filter(
        usp_video=video
    ).order_by('-id')

    feedbacks = USPFeedback.objects.filter(
        usp_video=video
    ).order_by('-id')

    complaints = USPComplaint.objects.filter(
        usp_video=video
    ).order_by('-id')

    return render(
        request,
        'session_details.html',
        {
            'video': video,
            'comments': comments,
            'feedbacks': feedbacks,
            'complaints': complaints
        }
    )
    
    #-------------myactivit -----------------
def my_activity(request):

    citizen_id = request.session.get(
        "citizen_id"
    )

    citizen = Citizen.objects.get(
        id=citizen_id
    )

    comments = USPComment.objects.filter(
        citizen=citizen
    ).order_by('-id')

    votes = USPVote.objects.filter(
        citizen=citizen
    ).order_by('-id')

    feedbacks = USPFeedback.objects.filter(
        citizen=citizen
    ).order_by('-id')

    complaints = USPComplaint.objects.filter(
        citizen=citizen
    ).order_by('-id')

    return render(
        request,
        'my_activity.html',
        {
            'citizen': citizen,
            'comments': comments,
            'votes': votes,
            'feedbacks': feedbacks,
            'complaints': complaints
        }
    )
    
#---------------mp activity----------
def mp_activity(request):

    mp_id = request.session.get(
        "mp_id"
    )

    mp = MP.objects.get(
        id=mp_id
    )

    total_videos = USPVideo.objects.count()

    total_comments = USPComment.objects.count()

    total_votes = USPVote.objects.count()

    total_feedbacks = USPFeedback.objects.count()

    total_complaints = USPComplaint.objects.count()

    return render(
        request,
        "mp_activity.html",
        {
            "mp": mp,
            "total_videos": total_videos,
            "total_comments": total_comments,
            "total_votes": total_votes,
            "total_feedbacks": total_feedbacks,
            "total_complaints": total_complaints
        }
    )
    
def my_votes(request):
    return render(request,'my_votes.html')


def my_comments(request):
    return render(request,'my_comments.html')


def my_feedbacks(request):
    return render(request,'my_feedbacks.html')


def my_complaints(request):
    return render(request,'my_complaints.html')


def citizen_profile(request):
    return render(request,'citizen_profile.html')


#----------------------------video-commens.html----------------------
def video_comments(request, pk):

    video = USPVideo.objects.get(id=pk)

    comments = USPComment.objects.filter(
        usp_video=video
    ).order_by('-created_at')

    return render(
        request,
        "video_comments.html",
        {
            "video": video,
            "comments": comments
        }
    )