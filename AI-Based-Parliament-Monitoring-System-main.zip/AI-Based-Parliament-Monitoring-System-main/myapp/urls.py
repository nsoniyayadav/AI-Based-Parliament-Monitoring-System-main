from django.urls import path

from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('register/', views.register_view, name='register'),

    # YouTube Import Page
    path(
        'youtube-videos/',
        views.youtube_upload,
        name='youtube_upload'
    ),

    # Citizen / MP dashboards
    path('citizen/dashboard/', views.citizen_dashboard, name='citizen_dashboard'),
    path('mp/dashboard/', views.mp_dashboard, name='mp_dashboard'),

    # Custom admin dashboard (must not conflict with Django's /admin/)
    path('admin-dashboard/', views.admin_dashboard, name='admin_dashboard'),

    # Citizen management (page render)
    path('admin/citizens/data-page/', views.citizen_data_page, name='citizen_data_page'),

    # Required navigation route: /citizens/ -> citizen_data.html
    path('citizens/', views.citizen_data_page, name='citizen_data_page'),

    # Admin HTML page routes (connect sidebar menu items to existing templates)
    path('admin/citizens/', views.citizen_data_page, name='admin_citizens_page'),

    path('mps/', views.admin_mp_data_page, name='mps'),
    path('mp-admin-ids/', views.admin_mp_admin_ids_page, name='mp_admin_ids'),
    path('mp-face-detections/', views.admin_mp_face_detections_page, name='mp_face_detections'),

    # MP Face Detection DB-driven upload/list endpoints
    path('mp-face-detections/list/', views.mp_face_detection_list, name='mp_face_detection_list'),
    path('mp-face-detections/single-upload/', views.mp_face_single_upload, name='mp_face_single_upload'),
    path('mp-face-detections/excel-upload/', views.mp_face_excel_upload, name='mp_face_excel_upload'),
    path('mp-face-detections/zip-upload/', views.mp_face_zip_upload, name='mp_face_zip_upload'),

    # MP Face Detection edit/delete
    path('mp-face-detections/single-edit/', views.mp_face_single_edit, name='mp_face_single_edit'),
    path('mp-face-detections/delete/', views.mp_face_delete, name='mp_face_delete'),

    # MP Face Detection bulk API (existing; URL kept for compatibility)
    path('api/mp-face-detections/bulk-create/', views.api_mp_face_detections_create_bulk, name='api_mp_face_detections_create_bulk'),

    path('offline-video-uploads/', views.admin_offline_video_uploads_page, name='offline_video_uploads'),

    # Admin YouTube Videos Page
    path(
        'admin-youtube-videos/',
        views.admin_youtube_videos_page,
        name='youtube_videos'
    ),

    path('usp-videos/', views.admin_usp_videos_page, name='usp_videos'),
    path('comments/', views.admin_comments_page, name='comments'),
    path('votes/', views.admin_votes_page, name='votes'),

    # Existing template file is admin_complent.html (typo preserved)
    path('complaints/', views.admin_complaints_page, name='complaints'),
    path('feedback/', views.admin_feedback_page, name='feedback'),

    # Data endpoints used by admin_dashboard.html JavaScript.
    path(
        'admin/dashboard/model/<str:model_key>/data/',
        views.admin_model_data,
        name='admin_model_data',
    ),

    path(
        'admin/dashboard/model/<str:model_name>/data/',
        views.admin_model_data,
        name='admin_model_data_alias',
    ),

    path(
        'admin/dashboard/model/<str:model_key>/crud/<int:pk>/<str:action>/',
        views.admin_model_crud,
        name='admin_model_crud',
    ),
    

#----------------------

path('generate-usp/<int:pk>/',views.generate_usp_video,name='generate_usp_video'),
path('usp-videos-page/',views.admin_usp_videos_page,name='usp_videos_page'),

path('live-session/',views.live_session,name='live_session'),
path('session-player/',views.session_player,name='session_player'),
path('go-live/<int:pk>/',views.go_live,name='go_live'),
path('stop-live/',views.stop_live,name='stop_live'),

#--------------for comments ,vote,,etc------------------------------
path('add-comment/<int:pk>/',views.add_comment,name='add_comment'),

path('add-vote/<int:pk>/',views.add_vote,name='add_vote'),

path('add-feedback/<int:pk>/',views.add_feedback,name='add_feedback'),

path('add-complaint/<int:pk>/',views.add_complaint,name='add_complaint'),

path('session-history/',views.session_history,name='session_history'),

path('session-details/<int:pk>/',views.session_details,name='session_details'),

path('my-activity/',views.my_activity,name='my_activity'),

path('mp-activity/',views.mp_activity,name='mp_activity'),




path(
    'session-history/',
    views.session_history,
    name='session_history'
),

path(
    'my-votes/',
    views.my_votes,
    name='my_votes'
),

path(
    'my-comments/',
    views.my_comments,
    name='my_comments'
),

path(
    'my-feedbacks/',
    views.my_feedbacks,
    name='my_feedbacks'
),

path(
    'my-complaints/',
    views.my_complaints,
    name='my_complaints'
),

path(
    'citizen-profile/',
    views.citizen_profile,
    name='citizen_profile'
),


]